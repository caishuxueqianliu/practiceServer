
# -* - coding: UTF-8 -* -


import os
import sys 
reload(sys)
 
def fileList(path):
    filelist = {}
    n = 0
    for root, folders, files in os.walk(path):
        for file in files:
            n += 1
            filelist[file] = os.path.join(root, file)
    print('\r扫描了 %s 个文件 ------- %s' % (n, path))
    return filelist
 
 
def compare(path1, path2):
    dict1 = fileList(path1)
    str1 = ''.join(dict1.values())
    suffix1 = os.path.splitext(str1)[0]
    files1 = os.path.basename(os.path.normpath(suffix1))
    print files1

    dict2 = fileList(path2)
    str2 = ''.join(dict2.values())
    suffix2 = os.path.splitext(str2)[0]
    files2 = os.path.basename(os.path.normpath(suffix2))
    print files2

    print('----------------------------------相同的---------------------------------')
    if files1 == files2:
        print suffix1,suffix2
 
 
if __name__ == '__main__':
    # path1 = r'/Users/admin/Desktop/jsc'
    # path2 = r'/Users/admin/Desktop/ceshi'
    path1 = sys.argv[1]
    path2 = sys.argv[2]
 
    compare(path1, path2)
 
    print("比对完成.")